kwriteconfig5 --file kwalletrc 'Wallet' 'enabled' 'true'
kwalletmanager &
