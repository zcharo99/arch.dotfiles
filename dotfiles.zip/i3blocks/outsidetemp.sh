sleep 5
echo -e "󱣖 $(curl -s wttr.in?format=%t)"
